package com.tkvsoft.titto;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Display extends AppCompatActivity {

    SQLiteDatabase db;
    ArrayList<String> name=new ArrayList<String>();
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);


        listView=(ListView)findViewById(R.id.listView);


        db = openOrCreateDatabase("UsersDB", Context.MODE_PRIVATE, null);
        if (db != null) {
            Toast.makeText(this, "Created", Toast.LENGTH_SHORT).show();
        }
        if (db != null) {
            db.execSQL("CREATE TABLE IF NOT EXISTS users(user_id VARCHAR,user_name VARCHAR,user_place VARCHAR);");
        }






        Cursor c = db.rawQuery("SELECT * FROM users", null);
        int cnt=c.getCount();
       // Toast.makeText(getApplicationContext(),"row count is  "+c+ "count is" +cnt,Toast.LENGTH_LONG).show();
        Log.e("msg","row count is  "+c);
        if (c.getCount() == 0) {

            showMessage("Error", "No records found");
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (c.moveToNext()) {
            String nm=c.getString(1).toString();
            name.add(nm);
        }
        ArrayAdapter<String> ad=new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1,name);
        listView.setAdapter(ad);

        c.close();

    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
